# Tanova AI: foto kamera dianalisis di backend

```
ESP32-S3 CAM --foto JPEG--> POST /api/v1/ai/analyze --> Gemini --> tabel ai_diagnoses (+ foto)
                              (header x-api-key)                      |
                                                                      +--> severity "high" = notifikasi di aplikasi
```

ESP32 hanya mengambil dan mengirim foto. Kunci Gemini tidak pernah ada di ESP32, hanya di `.env` backend.

## 1. Isi `.env` backend

```
GEMINI_API_KEY=<dari Google AI Studio>
GEMINI_MODEL=gemini-3.5-flash
CAMERA_API_KEY=<string acak panjang buatan Anda>
```

`GEMINI_MODEL` harus berupa id model persis (huruf kecil, tanda hubung). Nama seperti `Gemini-3.5-Flash-Lite` ditolak Gemini dengan error "unexpected model name format".

Opsional, agar foto disimpan di Supabase Storage (seperti layanan lama): buat bucket publik `tanova-images`, lalu isi `SUPABASE_URL` dan `SUPABASE_SERVICE_KEY` (Project Settings > API > service_role). Kunci ini rahasia, jangan di-commit. Kalau dikosongkan, foto disimpan di folder `uploads/` backend.

Restart backend, lalu buka `/health`. Field `ai` harus berisi nama model, bukan `not_configured`.

## 2. Uji dari terminal

`device_id` adalah ID perangkat **Tanova** (field `id` di `GET /devices`).

```bash
curl -X POST "http://localhost:3000/api/v1/ai/analyze?device_id=<ID_PERANGKAT_TANOVA>" \
  -H "x-api-key: <CAMERA_API_KEY>" \
  -H "Content-Type: image/jpeg" \
  --data-binary @daun.jpg
```

Atau multipart seperti layanan lama: `-F "image=@daun.jpg"` (tanpa `Content-Type` manual). Di Swagger (`/docs`) endpoint ini punya kotak unggah file; klik Authorize dengan JWT, atau isi `cameraKey`.

Hasil (201):

```json
{ "saved": true, "id": "...", "category": "pest", "label": "Hama Kumbang Loncat", "confidence": 0.95,
  "severity": "high", "recommendation": "...", "recommended_actions": ["..."],
  "image_url": "...", "details": { "source": "camera", "plant": "Sawi", "symptoms": ["..."], "model": "gemini-3.5-flash", "latency_ms": 6008 } }
```

Jika foto bukan tanaman atau terlalu gelap/buram: `{ "saved": false, "is_plant": false, ... }` dan tidak ada yang disimpan.

## 3. Pengganti endpoint layanan lama

| Layanan lama | Backend Tanova |
| --- | --- |
| `GET /health` | `GET /health` (ada field `ai`) |
| `POST /api/analyze` | `POST /api/v1/ai/analyze` |
| `GET /api/logs` | `GET /api/v1/ai/diagnoses` (filter: `device_id`, `severity`, `from`, `to`, `page`, `limit`) |

## 4. Kode ESP32-S3 CAM (Arduino)

Kamera harus dalam mode JPEG. Alamat backend harus bisa dijangkau ESP32: `localhost` tidak bisa, pakai IP laptop di WiFi yang sama (contoh `http://192.168.1.10:3000`) atau alamat server yang sudah di-deploy.

```cpp
#include <WiFi.h>
#include <HTTPClient.h>
#include "esp_camera.h"

const char* BACKEND   = "http://192.168.1.10:3000";
const char* DEVICE_ID = "5c88aa81-fd67-487c-985d-59bfbc94a756";  // ID perangkat Tanova
const char* CAMERA_KEY = "ISI_CAMERA_API_KEY";

bool kirimFoto() {
  camera_fb_t* fb = esp_camera_fb_get();
  if (!fb) return false;

  HTTPClient http;
  http.begin(String(BACKEND) + "/api/v1/ai/analyze?device_id=" + DEVICE_ID);
  http.setTimeout(35000);                       // analisis AI butuh sekitar 5-15 detik
  http.addHeader("Content-Type", "image/jpeg");
  http.addHeader("x-api-key", CAMERA_KEY);
  int code = http.POST(fb->buf, fb->len);
  Serial.printf("HTTP %d: %s\n", code, http.getString().c_str());
  http.end();

  esp_camera_fb_return(fb);
  return code == 201 || code == 200;
}
```

Untuk alamat `https://`, pakai `WiFiClientSecure client; client.setInsecure(); http.begin(client, url);`.

Saran: kirim foto tiap 30 menit sampai beberapa jam, bukan tiap beberapa detik. Tiap foto memanggil Gemini (ada batas kuota/biaya), dan diagnosis `high` yang berulang membuat notifikasi berulang. Buang 1-2 frame pertama setelah kamera menyala supaya eksposur stabil. Backend membatasi 20 permintaan per menit untuk endpoint ini.

## 5. Kode error yang mungkin muncul

| Status / code | Artinya |
| --- | --- |
| 401 `INVALID_API_KEY` | `x-api-key` tidak sama dengan `CAMERA_API_KEY` (atau kosong di `.env`) |
| 404 `DEVICE_NOT_FOUND` | `device_id` bukan ID perangkat Tanova |
| 415 `UNSUPPORTED_IMAGE` | Isi bukan JPEG/PNG/WebP, biasanya frame terpotong |
| 503 `AI_NOT_CONFIGURED` | `GEMINI_API_KEY` belum diisi |
| 502 `AI_PROVIDER_ERROR` | Gemini menolak (nama model salah, kunci salah, kuota habis). Pesan aslinya ada di log backend |
| 504 `AI_UNREACHABLE` | Gemini terlalu lama menjawab atau tidak terjangkau |
